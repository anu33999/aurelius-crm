"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import { api, placeOf } from "@/lib/client";
import { NICHES, NICHE_GROUPS } from "@/lib/niches";
import { FLAG_LABEL, type ProspectFlag } from "@/lib/leads/score";
import { telHref, waLink } from "@/lib/outreach";
import { COUNTRIES, HUBS, HUB_NAMES, REGIONS } from "@/lib/hubs";
import { PIPELINE_STAGES, type BusinessDTO } from "@/lib/types";
import { StarButton } from "./StarButton";
import { recommendServices } from "@/lib/leads/plan";
import { snapshotWithAudit } from "@/lib/leads/snapshot";
import type { AuditResult, ServiceDef } from "@/lib/types";
import { quoteFor } from "@/lib/leads/quote";
import { CatalogueImport } from "./CatalogueImport";
import { ExportButtons } from "./ExportButtons";
import { Badge, ErrorBox, InfoBox, SectionTitle, Spinner } from "./ui";

const stageLabel = (k: string) => PIPELINE_STAGES.find((s) => s.key === k)?.label ?? k;

export function DirectoryTab({
  businesses,
  reload,
  onAudit,
  onPlan,
  onToggleStar,
}: {
  businesses: BusinessDTO[];
  reload: () => void;
  onAudit: (b: BusinessDTO) => void;
  onPlan: (b: BusinessDTO) => void;
  onToggleStar: (b: BusinessDTO) => void;
}) {
  const [q, setQ] = useState("");
  const [region, setRegion] = useState("");
  const [country, setCountry] = useState("");
  const [industry, setIndustry] = useState("");
  const [hub, setHub] = useState(HUB_NAMES[0]);
  const [customCity, setCustomCity] = useState("");
  const [niche, setNiche] = useState("");
  const [webMode, setWebMode] = useState<"any" | "with" | "without" | "bare">("any");
  const [fNiche, setFNiche] = useState("");
  const [fFlag, setFFlag] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [catalogue, setCatalogue] = useState<ServiceDef[]>([]);
  const [perUSD, setPerUSD] = useState<Record<string, number> | null>(null);
  useEffect(() => {
    api<{ perUSD: Record<string, number> }>("/api/rates").then((r) => setPerUSD(r.perUSD)).catch(() => undefined);
  }, []);
  const [audits, setAudits] = useState<Record<string, AuditResult | null>>({});
  useEffect(() => {
    api<{ services: ServiceDef[] }>("/api/catalogue").then((r) => setCatalogue(r.services)).catch(() => undefined);
  }, []);
  function toggle(b: BusinessDTO) {
    const next = open === b.id ? null : b.id;
    setOpen(next);
    if (next && b.lastAuditedAt && !(b.id in audits)) {
      api<{ audit: AuditResult | null }>(`/api/audit?businessId=${b.id}`).then((r) => setAudits((a) => ({ ...a, [b.id]: r.audit }))).catch(() => setAudits((a) => ({ ...a, [b.id]: null })));
    }
  }
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const industries = useMemo(() => [...new Set(businesses.map((b) => b.industry).filter(Boolean) as string[])].sort(), [businesses]);

  // Countries present in the data (presets plus anything imported via "any city").
  const countries = useMemo(() => [...new Set([...COUNTRIES, ...(businesses.map((b) => b.country).filter(Boolean) as string[])])].sort(), [businesses]);
  const regionOf = (c: string | null) => HUBS.find((h) => h.country === c)?.region ?? null;

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return businesses.filter((b) => {
      if (country && b.country !== country) return false;
      if (region && regionOf(b.country) !== region) return false;
      if (industry && b.industry !== industry) return false;
      if (fNiche && b.niche !== fNiche) return false;
      if (fFlag && !b.flags.includes(fFlag)) return false;
      if (needle && !`${b.name} ${b.industry ?? ""} ${b.website ?? ""} ${b.city} ${b.country ?? ""}`.toLowerCase().includes(needle)) return false;
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [businesses, q, region, country, industry, fNiche, fFlag]);

  async function discover(custom?: string) {
    setBusy(true);
    setMsg(null);
    setError(null);
    try {
      const res = await api<{ found: number; created: number; skipped: number; place: string; provider: string }>("/api/discover", {
        method: "POST",
        body: JSON.stringify({ ...(custom ? { city: custom } : { hub }), niche: niche || null, websiteMode: webMode }),
      });
      setMsg(`${res.place}: ${res.found} real listings found via ${res.provider}, ${res.created} added, ${res.skipped} already in the directory.`);
      if (custom) setCustomCity("");
      reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Discovery failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <CatalogueImport />
          <ExportButtons scope="directory" params={{ country, niche: fNiche }} />
        </div>
        <SectionTitle sub="Real businesses to pitch, by market and niche: North America, Europe, the Middle East, Asia-Pacific, India and beyond. Import live listings by market or any city, or add your own.">
          International Prospect Directory
        </SectionTitle>
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="label">Market</label>
            <select className="input !w-auto" value={hub} onChange={(e) => setHub(e.target.value)}>
              {REGIONS.map((r) => (
                <optgroup key={r} label={r}>
                  {HUBS.filter((h) => h.region === r).map((h) => (
                    <option key={h.name} value={h.name}>{h.name}, {h.country}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Niche</label>
            <select className="input !w-auto" value={niche} onChange={(e) => setNiche(e.target.value)}>
              <option value="">Any commercial business</option>
              {NICHE_GROUPS.map((g) => (
                <optgroup key={g} label={g}>
                  {NICHES.filter((n) => n.group === g).map((n) => (
                    <option key={n.id} value={n.id}>{n.label}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Online presence</label>
            <select className="input !w-auto" value={webMode} onChange={(e) => setWebMode(e.target.value as typeof webMode)}>
              <option value="any">Everyone (with or without a website)</option>
              <option value="without">No website yet</option>
              <option value="bare">No website and no social links (new businesses)</option>
              <option value="with">Only with a website</option>
            </select>
          </div>
          <button className="btn-gold" disabled={busy} onClick={() => discover()}>
            {busy ? "Importing…" : niche ? "Find prospects" : "Import market"}
          </button>
          <div className="flex items-end gap-2 md:ml-4">
            <div>
              <label className="label">Or any city</label>
              <input className="input !w-56" placeholder="e.g. Lisbon, Portugal" value={customCity} onChange={(e) => setCustomCity(e.target.value)} onKeyDown={(e) => e.key === "Enter" && customCity.trim() && !busy && discover(customCity)} />
            </div>
            <button className="btn-ghost" disabled={busy || !customCity.trim()} onClick={() => discover(customCity)}>Import city</button>
          </div>
          <button className="btn-ghost" onClick={() => setShowAdd((v) => !v)}>
            {showAdd ? "Close form" : "+ Add business"}
          </button>
        </div>
        {busy && (
          <div className="mt-3">
            <Spinner label="Querying OpenStreetMap (this can take up to a minute for large cities)…" />
          </div>
        )}
        {msg && <p className="mt-3 text-sm text-gold">{msg}</p>}
        {error && (
          <div className="mt-3">
            <ErrorBox>{error}</ErrorBox>
          </div>
        )}
        <p className="mt-3 text-xs text-cream/45">
          OpenStreetMap is community-maintained and its coverage varies by country: imported records only contain what OSM holds (often no phone or email) and should be verified before outreach. A niche search also finds businesses with no website, which are the highest-margin pitches. Add a Google Places key to include ratings and review counts.
        </p>
        {showAdd && <AddForm onDone={() => { setShowAdd(false); reload(); }} />}
      </div>

      <div className="flex flex-wrap gap-3">
        <input className="input !w-64" placeholder="Search name, industry, city, country…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input !w-auto" value={region} onChange={(e) => setRegion(e.target.value)}>
          <option value="">All regions</option>
          {REGIONS.map((r) => (
            <option key={r}>{r}</option>
          ))}
        </select>
        <select className="input !w-auto" value={country} onChange={(e) => setCountry(e.target.value)}>
          <option value="">All countries</option>
          {countries.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
        <select className="input !w-auto" value={industry} onChange={(e) => setIndustry(e.target.value)}>
          <option value="">All industries</option>
          {industries.map((i) => (
            <option key={i}>{i}</option>
          ))}
        </select>
        <select className="input !w-auto" value={fNiche} onChange={(e) => setFNiche(e.target.value)}>
          <option value="">All niches</option>
          {NICHES.map((n) => (
            <option key={n.id} value={n.id}>{n.label}</option>
          ))}
        </select>
        <select className="input !w-auto" value={fFlag} onChange={(e) => setFFlag(e.target.value)}>
          <option value="">Any opportunity</option>
          {(Object.keys(FLAG_LABEL) as ProspectFlag[]).map((f) => (
            <option key={f} value={f}>{FLAG_LABEL[f]}</option>
          ))}
        </select>
        <span className="self-center text-sm text-cream/50">{rows.length} of {businesses.length}</span>
      </div>

      {businesses.length === 0 ? (
        <InfoBox>The directory is empty. Import a market or any city from OpenStreetMap, or add a business to start.</InfoBox>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[980px] text-left text-sm">
            <thead className="border-b border-cream/10 text-[11px] uppercase tracking-wider text-gold/80">
              <tr>
                <th className="px-3 py-2.5">Business</th>
                <th className="px-3 py-2.5">Industry</th>
                <th className="px-3 py-2.5">Location</th>
                <th className="px-3 py-2.5">Contact</th>
                <th className="px-3 py-2.5">Signals</th>
                <th className="px-3 py-2.5">Stage</th>
                <th className="px-3 py-2.5">Opp.</th>
                <th className="px-3 py-2.5">Suggested price</th>
                <th className="px-3 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {rows.map((b) => (
                <Fragment key={b.id}>
                <tr className="border-b border-cream/5 hover:bg-cream/[0.04]">
                  <td className="px-3 py-2.5">
                    <div className="font-medium">{b.name}</div>
                    {b.website && (
                      <a className="text-xs text-gold hover:underline" href={/^https?:/i.test(b.website) ? b.website : `https://${b.website}`} target="_blank" rel="noreferrer">
                        {b.website.replace(/^https?:\/\//, "").slice(0, 38)}
                      </a>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-cream/75">{b.industry ?? "-"}</td>
                  <td className="px-3 py-2.5 text-cream/75">{placeOf(b)}</td>
                  <td className="px-3 py-2.5 text-cream/75">
                    {b.phone ? (
                      <div className="flex flex-col gap-0.5">
                        <a className="hover:text-gold" href={telHref(b.phone, b.country) ?? undefined}>{b.phone}</a>
                        {waLink(b.phone, "", b.country) && (
                          <a className="text-[11px] text-emerald hover:underline" href={waLink(b.phone, `Hi, is this ${b.name}?`, b.country) ?? undefined} target="_blank" rel="noreferrer">WhatsApp</a>
                        )}
                      </div>
                    ) : (
                      <span className="text-cream/35">no phone</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex max-w-[210px] flex-wrap gap-1">
                      {b.googleRating != null && <Badge tone="cream">{b.googleRating.toFixed(1)} ★{b.reviewCount != null ? ` (${b.reviewCount})` : ""}</Badge>}
                      {b.flags.filter((f) => f !== "NO_PHONE").map((f) => (
                        <Badge key={f} tone={f === "NO_WEBSITE" ? "crimson" : f === "NO_SOCIAL" ? "slate" : "amber"}>{FLAG_LABEL[f as ProspectFlag] ?? f}</Badge>
                      ))}
                    </div>
                  </td>
                  <td className="px-3 py-2.5"><Badge tone={b.pipelineStage === "LEAD" ? "slate" : b.pipelineStage === "PITCH_SENT" ? "amber" : b.pipelineStage === "CLOSED_LOST" ? "crimson" : "emerald"}>{stageLabel(b.pipelineStage)}</Badge></td>
                  <td className="px-3 py-2.5 text-cream/75">{b.opportunityScore ?? "-"}</td>
                  <td className="px-3 py-2.5 text-xs">
                    {perUSD ? (() => {
                      const q = quoteFor(b, perUSD);
                      return (
                        <div className="min-w-[130px]" title="Your asking price from data/pricing.json, in this prospect's currency">
                          <div className="font-medium text-cream">{q.tierLabel} · {q.monthlyDisplay}</div>
                          {q.websiteBuildDisplay && <div className="text-cream/65">+ {q.websiteBuildDisplay} website build</div>}
                          {q.usdDisplay && <div className="text-cream/40">{q.usdDisplay}</div>}
                        </div>
                      );
                    })() : <span className="text-cream/30">…</span>}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <div className="flex justify-end gap-1.5">
                      <button className="btn-ghost !py-1 text-xs" onClick={() => toggle(b)} aria-expanded={open === b.id}>{open === b.id ? "Hide" : "Details"}</button>
                      <StarButton on={b.shortlisted} onToggle={() => onToggleStar(b)} label="Select" />
                      <button className="btn-gold !py-1 text-xs" onClick={() => onPlan(b)} title="Recommended services, price and outreach kit">Offer</button>
                      <button className="btn-ghost !py-1 text-xs" onClick={() => onAudit(b)}>Audit</button>
                    </div>
                  </td>
                </tr>
                {open === b.id && (() => {
                  const snap = snapshotWithAudit(b, audits[b.id] ?? null);
                  const pitch = recommendServices(b, catalogue).slice(0, 4);
                  return (
                    <tr className="border-b border-cream/10 bg-obsidian/60">
                      <td colSpan={10} className="px-4 py-4">
                        <div className="grid gap-4 md:grid-cols-3">
                          <div>
                            <div className="label">Already has</div>
                            {snap.has.length ? <ul className="space-y-1 text-[13px]">{snap.has.map((x) => <li key={x} className="text-emerald">✓ <span className="text-cream/85">{x}</span></li>)}</ul> : <p className="text-[13px] text-cream/50">Nothing confirmed yet.</p>}
                          </div>
                          <div>
                            <div className="label">Missing</div>
                            {snap.missing.length ? <ul className="space-y-1 text-[13px]">{snap.missing.map((x) => <li key={x} className="text-crimson">✗ <span className="text-cream/85">{x}</span></li>)}</ul> : <p className="text-[13px] text-cream/50">No gaps found in the data we hold.</p>}
                            {!snap.fromAudit && <p className="mt-2 text-[11px] text-cream/45">{b.website ? "Run an audit for website, tracking and conversion gaps." : "Based on listing data only."}</p>}
                          </div>
                          <div>
                            <div className="label">What we can pitch</div>
                            <ul className="space-y-1.5 text-[13px]">
                              {pitch.map((s) => (
                                <li key={s.code}>
                                  <span className="font-medium text-gold">{s.name}</span>
                                  <div className="text-[11px] text-cream/55">{s.why[0]}</div>
                                </li>
                              ))}
                            </ul>
                            <button className="btn-gold mt-2 !py-1 text-xs" onClick={() => onPlan(b)}>Full offer, price & outreach</button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })()}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function AddForm({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ name: "", website: "", industry: "", phone: "", email: "", city: "", country: "", address: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  async function save() {
    setBusy(true);
    setError(null);
    try {
      await api("/api/businesses", {
        method: "POST",
        body: JSON.stringify({
          ...f,
          city: f.city.trim() || "Unspecified",
          country: f.country.trim() || null,
          website: f.website || null,
          industry: f.industry || null,
          phone: f.phone || null,
          email: f.email || null,
          address: f.address || null,
        }),
      });
      onDone();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-4 grid gap-3 border-t border-cream/10 pt-4 md:grid-cols-3">
      <div><label className="label">Name *</label><input className="input" value={f.name} onChange={set("name")} /></div>
      <div><label className="label">Website</label><input className="input" value={f.website} onChange={set("website")} placeholder="https://" /></div>
      <div><label className="label">Industry</label><input className="input" value={f.industry} onChange={set("industry")} placeholder="DTC E-Commerce, SaaS…" /></div>
      <div><label className="label">Phone</label><input className="input" value={f.phone} onChange={set("phone")} /></div>
      <div><label className="label">Email</label><input className="input" value={f.email} onChange={set("email")} /></div>
      <div><label className="label">City</label><input className="input" value={f.city} onChange={set("city")} placeholder="London" /></div>
      <div>
        <label className="label">Country</label>
        <input className="input" list="country-list" value={f.country} onChange={set("country")} placeholder="United Kingdom" />
        <datalist id="country-list">{COUNTRIES.map((c) => <option key={c} value={c} />)}</datalist>
      </div>
      <div><label className="label">Address</label><input className="input" value={f.address} onChange={set("address")} /></div>
      <div className="flex items-end">
        <button className="btn-gold w-full" disabled={busy || !f.name.trim()} onClick={save}>{busy ? "Saving…" : "Save business"}</button>
      </div>
      {error && <div className="md:col-span-3"><ErrorBox>{error}</ErrorBox></div>}
    </div>
  );
}
