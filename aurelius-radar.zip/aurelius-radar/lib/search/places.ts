import type { BusinessInput } from "@/lib/db/repo";
import type { Hub } from "@/lib/hubs";
import { nicheById } from "@/lib/niches";

/**
 * Optional Google Places (New) Text Search. Only used when GOOGLE_PLACES_API_KEY is set; it adds
 * rating, review count and a phone number, which OpenStreetMap rarely has. Google does not expose
 * whether a Business Profile is "claimed", so that is never shown as a fact.
 * Check Google's Maps Platform terms for how long you may store Places content.
 */
export const placesConfigured = () => !!process.env.GOOGLE_PLACES_API_KEY;

interface Place {
  id: string;
  displayName?: { text?: string };
  formattedAddress?: string;
  location?: { latitude: number; longitude: number };
  rating?: number;
  userRatingCount?: number;
  websiteUri?: string;
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  businessStatus?: string;
}

const FIELDS = [
  "places.id",
  "places.displayName",
  "places.formattedAddress",
  "places.location",
  "places.rating",
  "places.userRatingCount",
  "places.websiteUri",
  "places.nationalPhoneNumber",
  "places.internationalPhoneNumber",
  "places.businessStatus",
].join(",");

export async function searchPlaces(hub: Hub, nicheId: string | null | undefined, limit = 20): Promise<BusinessInput[]> {
  const niche = nicheById(nicheId);
  const term = niche?.places ?? "businesses";
  const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "X-Goog-Api-Key": process.env.GOOGLE_PLACES_API_KEY as string,
      "X-Goog-FieldMask": FIELDS,
    },
    body: JSON.stringify({
      textQuery: `${term} in ${hub.name}, ${hub.country}`,
      pageSize: Math.min(limit, 20),
      languageCode: "en",
      locationBias: { circle: { center: { latitude: hub.lat, longitude: hub.lng }, radius: Math.min(hub.radiusM, 50000) } },
    }),
  });
  if (!res.ok) throw new Error(`Google Places ${res.status}: ${(await res.text()).slice(0, 200)}`);
  const data = (await res.json()) as { places?: Place[] };
  return (data.places ?? [])
    .filter((p) => p.displayName?.text && (!p.businessStatus || p.businessStatus === "OPERATIONAL"))
    .map((p) => ({
      name: p.displayName?.text as string,
      industry: niche?.label ?? null,
      niche: niche?.id ?? null,
      website: p.websiteUri ?? null,
      phone: p.internationalPhoneNumber ?? p.nationalPhoneNumber ?? null,
      address: p.formattedAddress ?? null,
      city: hub.name,
      country: hub.country,
      latitude: p.location?.latitude ?? null,
      longitude: p.location?.longitude ?? null,
      googleRating: p.rating ?? null,
      reviewCount: p.userRatingCount ?? null,
      googlePlaceId: p.id,
      source: "GOOGLE_PLACES",
    }));
}
