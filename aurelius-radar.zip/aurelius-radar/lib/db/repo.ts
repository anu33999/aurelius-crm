import { prisma } from "./client";
import { STARTER_CATALOGUE } from "@/lib/services/starter-catalogue";
import { scoreProspect } from "@/lib/leads/score";
import type {
  BusinessDTO,
  IntentCategory,
  LeadPitch,
  PipelineStage,
  Platform,
  Priority,
  ServiceDef,
  SocialLeadDTO,
} from "@/lib/types";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function toBusinessDTO(b: any): BusinessDTO {
  return {
    id: b.id,
    name: b.name,
    industry: b.industry ?? null,
    website: b.website ?? null,
    phone: b.phone ?? null,
    email: b.email ?? null,
    address: b.address ?? null,
    city: b.city,
    locality: b.locality ?? null,
    state: b.state ?? null,
    country: b.country ?? null,
    latitude: b.latitude ?? null,
    longitude: b.longitude ?? null,
    niche: b.niche ?? null,
    googleRating: b.googleRating ?? null,
    reviewCount: b.reviewCount ?? null,
    googlePlaceId: b.googlePlaceId ?? null,
    instagramUrl: b.instagramUrl ?? null,
    linkedinUrl: b.linkedinUrl ?? null,
    flags: parseJson<string[]>(b.opportunityFlags, []),
    shortlisted: !!b.shortlisted,
    lastContactedAt: b.lastContactedAt ? new Date(b.lastContactedAt).toISOString() : null,
    source: b.source ?? null,
    estimatedRevenue: b.estimatedRevenue ?? null,
    techStack: b.techStack ?? null,
    pipelineStage: b.pipelineStage as PipelineStage,
    priority: b.priority as Priority,
    monthlyBudget: b.monthlyBudget ?? null,
    notes: b.notes ?? null,
    pitchSummary: b.pitchSummary ?? null,
    matchedServiceIds: parseJson<string[]>(b.matchedServiceIds, []),
    readinessScore: b.readinessScore ?? null,
    opportunityScore: b.opportunityScore ?? null,
    lastAuditedAt: b.lastAuditedAt ? new Date(b.lastAuditedAt).toISOString() : null,
    createdAt: new Date(b.createdAt).toISOString(),
    updatedAt: new Date(b.updatedAt).toISOString(),
    noteCount: b._count?.crmNotes ?? 0,
  };
}

function toLeadDTO(l: any): SocialLeadDTO {
  return {
    id: l.id,
    platform: l.platform as Platform,
    sourceUrl: l.sourceUrl,
    authorHandle: l.authorHandle ?? null,
    postTitle: l.postTitle ?? null,
    postContent: l.postContent,
    postedAt: l.postedAt ? new Date(l.postedAt).toISOString() : null,
    painPoint: l.painPoint ?? null,
    matchedServices: parseJson<string[]>(l.matchedServices, []),
    intentCategory: l.intentCategory as IntentCategory,
    classifiedBy: (l.classifiedBy === "AI" ? "AI" : "RULES") as "AI" | "RULES",
    confidence: l.confidence ?? null,
    status: l.status,
    pitchDraft: parseJson<LeadPitch | null>(l.pitchDraft, null),
    shortlisted: !!l.shortlisted,
    createdAt: new Date(l.createdAt).toISOString(),
  };
}

/* ------------------------------------------------------------------ */
/* catalogue                                                           */
/* ------------------------------------------------------------------ */

export async function getCatalogue(): Promise<{ services: ServiceDef[]; isStarter: boolean }> {
  try {
    const rows: any[] = await prisma.service.findMany({ orderBy: { code: "asc" } });
    if (rows.length > 0) {
      return {
        isStarter: false,
        services: rows.map((r) => ({
          code: r.code,
          name: r.name,
          practiceArea: r.practiceArea,
          summary: r.summary ?? "",
          tags: (r.tags ?? "").split(",").map((t: string) => t.trim().toLowerCase()).filter(Boolean),
          isAI: !!r.isAI,
        })),
      };
    }
  } catch {
    // DB not initialised yet - fall through to the starter set.
  }
  return { services: STARTER_CATALOGUE, isStarter: true };
}

export async function replaceCatalogue(services: ServiceDef[]): Promise<number> {
  await prisma.service.deleteMany({});
  let n = 0;
  for (const svc of services) {
    await prisma.service.create({
      data: {
        code: svc.code,
        name: svc.name,
        practiceArea: svc.practiceArea,
        summary: svc.summary,
        tags: svc.tags.join(","),
        isAI: svc.isAI,
      },
    });
    n++;
  }
  return n;
}

/* ------------------------------------------------------------------ */
/* businesses                                                          */
/* ------------------------------------------------------------------ */

export interface BusinessFilter {
  q?: string;
  city?: string;
  country?: string;
  locality?: string;
  stage?: string;
  industry?: string;
}

export async function listBusinesses(f: BusinessFilter = {}): Promise<BusinessDTO[]> {
  const where: any = {};
  if (f.city) where.city = f.city;
  if (f.country) where.country = f.country;
  if (f.locality) where.locality = f.locality;
  if (f.stage) where.pipelineStage = f.stage;
  if (f.industry) where.industry = f.industry;
  if (f.q) {
    where.OR = [
      { name: { contains: f.q } },
      { industry: { contains: f.q } },
      { website: { contains: f.q } },
      { locality: { contains: f.q } },
      { city: { contains: f.q } },
      { country: { contains: f.q } },
    ];
  }
  const rows: any[] = await prisma.business.findMany({
    where,
    orderBy: [{ updatedAt: "desc" }],
    include: { _count: { select: { crmNotes: true } } },
    take: 1000,
  });
  return rows.map(toBusinessDTO);
}

export async function getBusiness(id: string): Promise<BusinessDTO | null> {
  const row = await prisma.business.findUnique({
    where: { id },
    include: { _count: { select: { crmNotes: true } } },
  });
  return row ? toBusinessDTO(row) : null;
}

export interface BusinessInput {
  name: string;
  industry?: string | null;
  website?: string | null;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  city?: string;
  locality?: string | null;
  state?: string | null;
  country?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  niche?: string | null;
  googleRating?: number | null;
  reviewCount?: number | null;
  googlePlaceId?: string | null;
  instagramUrl?: string | null;
  linkedinUrl?: string | null;
  pipelineStage?: PipelineStage;
  lastContactedAt?: Date | null;
  shortlisted?: boolean;
  source?: string | null;
  estimatedRevenue?: string | null;
  techStack?: string | null;
  monthlyBudget?: string | null;
  priority?: Priority;
}

export async function createBusiness(input: BusinessInput): Promise<BusinessDTO> {
  // Pre-audit opportunity score and flags from whatever listing data we have.
  const prospect = scoreProspect({
    niche: input.niche,
    website: input.website,
    phone: input.phone,
    email: input.email,
    googleRating: input.googleRating,
    reviewCount: input.reviewCount,
    instagramUrl: input.instagramUrl,
    linkedinUrl: input.linkedinUrl,
  });
  const row = await prisma.business.create({
    data: {
      name: input.name,
      industry: input.industry ?? null,
      website: input.website ?? null,
      phone: input.phone ?? null,
      email: input.email ?? null,
      address: input.address ?? null,
      city: input.city?.trim() || "Unspecified",
      locality: input.locality ?? null,
      state: input.state ?? null,
      country: input.country ?? null,
      latitude: input.latitude ?? null,
      longitude: input.longitude ?? null,
      niche: input.niche ?? null,
      googleRating: input.googleRating ?? null,
      reviewCount: input.reviewCount ?? null,
      googlePlaceId: input.googlePlaceId ?? null,
      instagramUrl: input.instagramUrl ?? null,
      linkedinUrl: input.linkedinUrl ?? null,
      opportunityFlags: JSON.stringify(prospect.flags),
      opportunityScore: prospect.score,
      pipelineStage: input.pipelineStage ?? "LEAD",
      lastContactedAt: input.lastContactedAt ?? null,
      source: input.source ?? "MANUAL",
      estimatedRevenue: input.estimatedRevenue ?? null,
      techStack: input.techStack ?? null,
      monthlyBudget: input.monthlyBudget ?? null,
      priority: input.priority ?? "MEDIUM",
    },
    include: { _count: { select: { crmNotes: true } } },
  });
  return toBusinessDTO(row);
}

/** Insert businesses that do not already exist (matched on lower-cased name + city + country). */
export async function bulkCreateBusinesses(items: BusinessInput[]): Promise<{ created: number; skipped: number }> {
  const existing: any[] = await prisma.business.findMany({ select: { name: true, city: true, country: true } });
  const keyOf = (n: string, c?: string | null, k?: string | null) => `${n.toLowerCase()}|${(c ?? "").toLowerCase()}|${(k ?? "").toLowerCase()}`;
  const seen = new Set(existing.map((e) => keyOf(e.name, e.city, e.country)));
  let created = 0;
  let skipped = 0;
  for (const item of items) {
    const key = keyOf(item.name, item.city, item.country);
    if (seen.has(key)) {
      skipped++;
      continue;
    }
    seen.add(key);
    await createBusiness(item);
    created++;
  }
  return { created, skipped };
}

const EDITABLE: (keyof BusinessDTO)[] = [
  "name",
  "industry",
  "website",
  "phone",
  "email",
  "address",
  "city",
  "locality",
  "state",
  "country",
  "latitude",
  "longitude",
  "niche",
  "googleRating",
  "reviewCount",
  "instagramUrl",
  "linkedinUrl",
  "lastContactedAt",
  "shortlisted",
  "estimatedRevenue",
  "techStack",
  "pipelineStage",
  "priority",
  "monthlyBudget",
  "notes",
  "pitchSummary",
];

export async function updateBusiness(id: string, patch: Record<string, unknown>): Promise<BusinessDTO | null> {
  const data: Record<string, unknown> = {};
  for (const key of EDITABLE) {
    if (key in patch) data[key] = patch[key as string];
  }
  if (Object.keys(data).length === 0) return getBusiness(id);
  // Moving a lead out of "New" counts as contact, which starts the 48-hour follow-up clock.
  if (typeof data.pipelineStage === "string" && data.pipelineStage !== "LEAD" && !("lastContactedAt" in data)) {
    const cur: any = await prisma.business.findUnique({ where: { id }, select: { pipelineStage: true } });
    if (cur && cur.pipelineStage !== data.pipelineStage) data.lastContactedAt = new Date();
  }
  if (typeof data.lastContactedAt === "string") data.lastContactedAt = new Date(data.lastContactedAt);
  const row = await prisma.business.update({
    where: { id },
    data,
    include: { _count: { select: { crmNotes: true } } },
  });
  return toBusinessDTO(row);
}

export async function deleteBusiness(id: string): Promise<void> {
  await prisma.business.delete({ where: { id } });
}

export async function saveAuditToBusiness(args: {
  businessId?: string;
  name: string;
  website: string | null;
  techStack: string | null;
  matchedServiceCodes: string[];
  readinessScore: number;
  opportunityScore: number;
  pitchSummary: string;
  auditJson: string;
  instagramUrl?: string | null;
  linkedinUrl?: string | null;
}): Promise<BusinessDTO> {
  const data = {
    website: args.website,
    techStack: args.techStack,
    matchedServiceIds: JSON.stringify(args.matchedServiceCodes),
    readinessScore: args.readinessScore,
    opportunityScore: args.opportunityScore,
    pitchSummary: args.pitchSummary,
    auditJson: args.auditJson,
    lastAuditedAt: new Date(),
    ...(args.instagramUrl ? { instagramUrl: args.instagramUrl } : {}),
    ...(args.linkedinUrl ? { linkedinUrl: args.linkedinUrl } : {}),
  };
  if (args.businessId) {
    const row = await prisma.business.update({
      where: { id: args.businessId },
      data,
      include: { _count: { select: { crmNotes: true } } },
    });
    return toBusinessDTO(row);
  }
  const row = await prisma.business.create({
    data: { name: args.name, city: "Unspecified", source: "AUDIT", ...data },
    include: { _count: { select: { crmNotes: true } } },
  });
  return toBusinessDTO(row);
}

export async function getAuditJson(businessId: string): Promise<string | null> {
  const row = await prisma.business.findUnique({ where: { id: businessId }, select: { auditJson: true } });
  return row?.auditJson ?? null;
}

/* ------------------------------------------------------------------ */
/* notes                                                               */
/* ------------------------------------------------------------------ */

export async function listNotes(businessId: string) {
  const rows: any[] = await prisma.businessNote.findMany({
    where: { businessId },
    orderBy: { createdAt: "desc" },
  });
  return rows.map((n) => ({
    id: n.id as string,
    content: n.content as string,
    author: n.author as string,
    createdAt: new Date(n.createdAt).toISOString(),
  }));
}

export async function addNote(businessId: string, content: string, author?: string) {
  const n = await prisma.businessNote.create({
    data: { businessId, content, ...(author ? { author } : {}) },
  });
  return { id: n.id as string, content: n.content as string, author: n.author as string, createdAt: new Date(n.createdAt).toISOString() };
}

/* ------------------------------------------------------------------ */
/* social leads                                                        */
/* ------------------------------------------------------------------ */

export interface LeadInput {
  platform: Platform;
  sourceUrl: string;
  authorHandle: string | null;
  postTitle: string | null;
  postContent: string;
  postedAt: Date | null;
  painPoint: string | null;
  matchedServices: string[];
  intentCategory: IntentCategory;
  classifiedBy: "AI" | "RULES";
  confidence: number | null;
  pitchDraft: LeadPitch | null;
}

/** Inserts new leads; existing source URLs are left untouched so status/notes are never overwritten. */
export async function insertNewLeads(items: LeadInput[]): Promise<{ created: number; duplicates: number }> {
  let created = 0;
  let duplicates = 0;
  for (const l of items) {
    const exists = await prisma.socialIntentLead.findUnique({ where: { sourceUrl: l.sourceUrl }, select: { id: true } });
    if (exists) {
      duplicates++;
      continue;
    }
    await prisma.socialIntentLead.create({
      data: {
        platform: l.platform,
        sourceUrl: l.sourceUrl,
        authorHandle: l.authorHandle,
        postTitle: l.postTitle,
        postContent: l.postContent,
        postedAt: l.postedAt,
        painPoint: l.painPoint,
        matchedServices: JSON.stringify(l.matchedServices),
        intentCategory: l.intentCategory,
        classifiedBy: l.classifiedBy,
        confidence: l.confidence,
        pitchDraft: l.pitchDraft ? JSON.stringify(l.pitchDraft) : null,
      },
    });
    created++;
  }
  return { created, duplicates };
}

export async function listLeads(filter: { platform?: string; status?: string; category?: string; shortlisted?: boolean } = {}): Promise<SocialLeadDTO[]> {
  const where: any = {};
  if (filter.platform) where.platform = filter.platform;
  if (filter.status) where.status = filter.status;
  if (filter.category) where.intentCategory = filter.category;
  if (filter.shortlisted) where.shortlisted = true;
  const rows: any[] = await prisma.socialIntentLead.findMany({
    where,
    orderBy: [{ createdAt: "desc" }],
    take: 500,
  });
  return rows.map(toLeadDTO);
}

export async function updateLead(id: string, patch: { status?: string; pitchDraft?: LeadPitch; shortlisted?: boolean }): Promise<SocialLeadDTO> {
  const data: Record<string, unknown> = {};
  if (patch.status) data.status = patch.status;
  if (patch.pitchDraft) data.pitchDraft = JSON.stringify(patch.pitchDraft);
  if (typeof patch.shortlisted === "boolean") data.shortlisted = patch.shortlisted;
  const row = await prisma.socialIntentLead.update({ where: { id }, data });
  return toLeadDTO(row);
}

export async function getLead(id: string): Promise<SocialLeadDTO | null> {
  const row = await prisma.socialIntentLead.findUnique({ where: { id } });
  return row ? toLeadDTO(row) : null;
}
