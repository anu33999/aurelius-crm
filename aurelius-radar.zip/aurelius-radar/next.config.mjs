/** @type {import('next').NextConfig} */
const nextConfig = {
  serverExternalPackages: ["@prisma/client", "cheerio", "pdfkit", "exceljs"],
};
export default nextConfig;
